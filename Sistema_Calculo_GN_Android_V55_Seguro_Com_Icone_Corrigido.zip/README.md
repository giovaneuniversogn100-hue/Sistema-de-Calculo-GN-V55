# Sistema de Cálculo GN — V55

Projeto Android criado a partir do protótipo V55 aprovado.

A interface original foi colocada como arquivo local em:
app/src/main/assets/index.html

O aplicativo usa WebView local, com JavaScript e armazenamento local habilitados,
para preservar o funcionamento do protótipo.

## Gerar APK pelo GitHub

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para o repositório.
3. Abra a aba Actions.
4. Execute "Gerar APK - Sistema de Cálculo GN".
5. Ao terminar, baixe o artefato "Sistema-de-Calculo-GN-V55".
6. Dentro dele estará o `app-debug.apk`.

Versão do aplicativo: 5.5


## Preparação contra os erros das tentativas anteriores

Esta versão mantém o V55 intacto e usa uma camada Android mínima em Java, sem
plugin/dependência Kotlin. O workflow fixa Java 17 + Gradle 8.9 + Android
Gradle Plugin 8.7.3, limpa o projeto antes da compilação e verifica as
dependências antes de gerar o APK. Isso evita repetir o cenário anterior de
classes Kotlin duplicadas e separa avisos de depreciação de erros reais de
compilação.
